import sqlite3
from werkzeug.security import generate_password_hash
import os
DB = os.path.join(os.path.dirname(__file__), "data", "websec.db")
os.makedirs(os.path.dirname(DB), exist_ok=True)
conn = sqlite3.connect(DB)
cur = conn.cursor()
cur.executescript("""
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS anggota;
DROP TABLE IF EXISTS comments;
""")
cur.execute("""CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE,
  password TEXT,
  password_hash TEXT,
  role TEXT
)""")
admin_plain = "admin123"
admin_hash = generate_password_hash(admin_plain)
cur.execute("INSERT INTO users(username,password,password_hash,role) VALUES(?,?,?,?)", ("admin", admin_plain, admin_hash, "admin"))
users = [("alice","alicepass","user"),("budi","budipass","user"),("charlie","charliepass","user")]
for u,p,r in users:
    cur.execute("INSERT INTO users(username,password,password_hash,role) VALUES(?,?,?,?)", (u,p,generate_password_hash(p),r))
cur.execute("""CREATE TABLE anggota (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nama TEXT,
  nim TEXT,
  jurusan TEXT,
  jabatan TEXT
)""")
sample = [
  ("Andi Wijaya","1806015010","Teknik Informatika","Ketua"),
  ("Siti Aminah","1806015011","Sistem Informasi","Sekretaris"),
  ("Rama Putra","1806015012","Teknik Elektro","Bendahara"),
  ("Dina Lestari","1806015013","Teknik Komputer","Anggota"),
]
for s in sample:
    cur.execute("INSERT INTO anggota(nama,nim,jurusan,jabatan) VALUES(?,?,?,?)", s)
cur.execute("""CREATE TABLE comments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  author TEXT,
  body TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)""")
cur.execute("INSERT INTO comments(author,body) VALUES(?,?)", ("System","Welcome to WebSec Playground"))
cur.execute("INSERT INTO comments(author,body) VALUES(?,?)", ("EvilDemo","[demo payload removed]"))
conn.commit()
conn.close()
print("Initialized database:", DB)
