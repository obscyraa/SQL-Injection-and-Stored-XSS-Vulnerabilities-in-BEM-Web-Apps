from flask import Flask, render_template, request, redirect, url_for, flash, session, send_from_directory
import sqlite3, os, json, requests, re
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash

APP_DIR = os.path.dirname(__file__)
DB_PATH = os.path.join(APP_DIR, "data", "websec.db")
MODE_FILE = os.path.join(APP_DIR, "mode.json")
UPLOAD_FOLDER = os.path.join(APP_DIR, "uploads")
os.makedirs(os.path.join(APP_DIR, "data"), exist_ok=True)
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def load_mode():
    if not os.path.exists(MODE_FILE):
        save_mode("VULNERABLE")
        return "VULNERABLE"
    try:
        with open(MODE_FILE,'r') as f:
            return json.load(f).get("mode","VULNERABLE")
    except:
        return "VULNERABLE"

def save_mode(mode):
    with open(MODE_FILE,'w') as f:
        json.dump({"mode":mode}, f)

app = Flask(__name__)
app.secret_key = "dev-secret-key"
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def get_db():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c

@app.context_processor
def inject_mode():
    return dict(MODE=load_mode())

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/toggle_mode", methods=["POST"])
def toggle_mode():
    cur = load_mode()
    nxt = "SECURE" if cur=="VULNERABLE" else "VULNERABLE"
    save_mode(nxt)
    flash(f"Mode changed to {nxt}")
    return redirect(url_for("index"))

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        username = request.form.get("username","")
        password = request.form.get("password","")
        mode = load_mode()
        db = get_db()
        cur = db.cursor()
        row = None
        if mode == "VULNERABLE":
            # Vulnerable: unsafely build SQL (SQLi possible)
            sql = f"SELECT id,username,role,password,password_hash FROM users WHERE username='{username}' AND (password='{password}' OR password_hash='{password}') LIMIT 1"
            try:
                cur.execute(sql)
                row = cur.fetchone()
            except Exception as e:
                row = None
        else:
            # Secure: parameterized query + proper password hash check
            cur.execute("SELECT id,username,role,password,password_hash FROM users WHERE username = ?", (username,))
            row = cur.fetchone()
            if row:
                stored_hash = row["password_hash"]
                stored_plain = row["password"]
                if stored_hash and stored_hash.startswith("pbkdf2:"):
                    ok = check_password_hash(stored_hash, password)
                else:
                    ok = (stored_plain == password)
                if not ok:
                    row = None
        db.close()
        if row:
            session['user'] = row['username']
            session['role'] = row['role']
            flash("Logged in as "+row['username'])
            return redirect(url_for("index"))
        flash("Login failed")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out")
    return redirect(url_for("index"))

@app.route("/members", methods=["GET","POST"])
def members():
    q = request.values.get("q","")
    db = get_db()
    cur = db.cursor()
    mode = load_mode()
    if q:
        if mode == "VULNERABLE":
            sql = f"SELECT id,nama,nim,jurusan,jabatan FROM anggota WHERE nama LIKE '%{q}%' OR nim LIKE '%{q}%' OR jabatan LIKE '%{q}%' ORDER BY id DESC"
            cur.execute(sql)
        else:
            like = f"%{q}%"
            cur.execute("SELECT id,nama,nim,jurusan,jabatan FROM anggota WHERE nama LIKE ? OR nim LIKE ? OR jabatan LIKE ? ORDER BY id DESC LIMIT 100", (like,like,like))
    else:
        cur.execute("SELECT id,nama,nim,jurusan,jabatan FROM anggota ORDER BY id DESC LIMIT 100")
    rows = cur.fetchall()
    db.close()
    return render_template("members.html", members=rows, q=q)

@app.route("/comments", methods=["GET","POST"])
def comments():
    db = get_db()
    cur = db.cursor()
    mode = load_mode()
    if request.method=="POST":
        author = request.form.get("author","Anonymous")
        body = request.form.get("body","")
        cur.execute("INSERT INTO comments(author,body) VALUES(?,?)", (author, body))
        db.commit()
        flash("Comment submitted")
        return redirect(url_for("comments"))
    cur.execute("SELECT id,author,body,created_at FROM comments ORDER BY id DESC LIMIT 200")
    rows = cur.fetchall()
    db.close()
    return render_template("comments.html", comments=rows)

def is_url_allowed(url):
    allowed_hosts = ["httpbin.org", "example.com"]
    try:
        from urllib.parse import urlparse
        p = urlparse(url)
        host = p.hostname
        if not host:
            return False
        if host.startswith("127.") or host in ("localhost","0.0.0.0"):
            return False
        return host in allowed_hosts
    except:
        return False

@app.route("/fetch", methods=["GET","POST"])
def fetch():
    content = None
    error = None
    if request.method=="POST":
        url = request.form.get("url","")
        mode = load_mode()
        try:
            if mode == "VULNERABLE":
                r = requests.get(url, timeout=5)
                content = r.text[:4000]
            else:
                if not is_url_allowed(url):
                    error = "URL not allowed in SECURE mode"
                else:
                    r = requests.get(url, timeout=5)
                    content = r.text[:4000]
        except Exception as e:
            error = str(e)
    return render_template("fetch.html", content=content, error=error)

ALLOWED_EXT = {'png','jpg','jpeg','pdf'}
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.',1)[1].lower() in ALLOWED_EXT

@app.route("/upload", methods=["GET","POST"])
def upload():
    mode = load_mode()
    if request.method=="POST":
        f = request.files.get("file")
        if not f:
            flash("No file uploaded")
            return redirect(url_for("upload"))
        filename = f.filename or "unnamed"
        if mode == "VULNERABLE":
            dest = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            f.save(dest)
            flash("File saved (vulnerable)")
            return redirect(url_for("upload"))
        else:
            if not allowed_file(filename):
                flash("File type not allowed in SECURE mode")
                return redirect(url_for("upload"))
            safe = secure_filename(filename)
            if re.search(r'\.(php|py|exe|sh)$', safe, re.IGNORECASE):
                flash("Rejected suspicious filename")
                return redirect(url_for("upload"))
            dest = os.path.join(app.config['UPLOAD_FOLDER'], safe)
            f.save(dest)
            flash("File saved securely")
            return redirect(url_for("upload"))
    files = os.listdir(app.config['UPLOAD_FOLDER'])
    return render_template("upload.html", files=files)

@app.route("/uploads/<path:filename>")
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename, as_attachment=False)

@app.route("/admin")
def admin_panel():
    if session.get("role") != "admin":
        flash("Admin only")
        return redirect(url_for("index"))
    return render_template("admin.html")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=9999, debug=True)
