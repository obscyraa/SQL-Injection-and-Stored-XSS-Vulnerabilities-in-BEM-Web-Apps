# WebSec Playground BEM

Educational web application to demonstrate common web vulnerabilities and their mitigations.
**For local use only** (do not expose to public networks).

Quickstart is in the repo.
